<?php

$sum = empty($_POST['money']) ? 0:$_POST['money'];
$b5000 = 0;
$b2000 = 0;
$b1000 = 0;
$b500 = 0;
$b100 = 0;
$b50 = 0;

//(int)$b5000=(int)intdiv((int)$sum,5000);
//(int)$sum = (int)$sum - (int)$b5000*5000;

$b2000=intdiv($sum,2000);
$sum = $sum - $b2000*2000;

$b1000=intdiv($sum,1000);
$sum = $sum - $b1000*1000;

$b500=intdiv($sum,500);
$sum = $sum - $b500*500;

$b200=intdiv($sum,200);
$sum = $sum - $b200*200;

$b100=intdiv($sum,100);
$sum = $sum - $b100*100;

$b50=intdiv($sum,50);
$sum = $sum - $b50*50;

$b10=intdiv($sum,10);
$sum = $sum - $b10*10;

$b5=intdiv($sum,5);
$sum = $sum - $b5*5;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Чудо</title>
</head>
<body>
    <table>
        <tr><td><img src="images/2000.jpg" alt="2000" width="200"></td><td><?php echo $b2000;?></td></tr>
        <tr><td><img src="images/1000.jpg" alt="1000" width="200"></td><td><?php echo $b1000;?></td></tr>
        <tr><td><img src="images/500.jpg" alt="500" width="200"></td><td><?php echo $b500;?></td></tr>
        <tr><td><img src="images/200.jpg" alt="200" width="200"></td><td><?php echo $b200;?></td></tr>
        <tr><td><img src="images/100.jpg" alt="100" width="200"></td><td><?php echo $b100;?></td></tr>
        <tr><td><img src="images/50.jpg" alt="50" width="200"></td><td><?php echo $b50;?></td></tr>
        <tr><td><img src="images/10.jpg" alt="10" width="200"></td><td><?php echo $b10;?></td></tr>
        <tr><td><img src="images/5.jpg" alt="5" width="200"></td><td><?php echo $b5;?></td></tr>
    </table>
</body>
</html>
