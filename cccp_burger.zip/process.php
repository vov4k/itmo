<?php
   $meet = empty($_POST['meet'])?0:$_POST['meet'];
   $cucumber = empty($_POST['cucumber'])?0:$_POST['cucumber'];
   $salad = empty($_POST['salad'])?0:$_POST['salad'];
   $onion = empty($_POST['onion'])?0:$_POST['onion'];
   $sauce = empty($_POST['sauce'])?0:$_POST['sauce'];
   $cheese = empty($_POST['cheese'])?0:$_POST['cheese'];

   $sum = 0;
   $sum += $meet*80;
   $sum += $cucumber*32;
   $sum += $salad*25;
   $sum += $onion*25;
   $sum += $sauce*30;
   $sum += $cheese*40;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Заказ</title>
</head>

<body>
    <table>
        <tr>
            <td>Ингредиент</td>
            <td>Цена за 1шт</td>
            <td>Количество</td>
            <td>Стоимость</td>
        </tr>
        <tr>
            <td>Бифштекс:</td>
            <td>80</td>
            <td><?php echo $meet ?></td>
            <td><?php echo $meet*80 ?></td>

        </tr>
        <tr>
            <td>Огурец маниров.:</td>
            <td>32</td>
            <td><?php echo $cucumber ?></td>
            <td><?php echo $cucumber*32 ?></td>
        </tr>
        <tr>
            <td>Салат:</td>
            <td>25</td>
            <td><?php echo $salad ?></td>
            <td><?php echo $salad*25 ?></td>
        </tr>
        <tr>
            <td>Лук:</td>
            <td>25</td>
            <td><?php echo $onion ?></td>
            <td><?php echo $onion*25 ?></td>
        </tr>
        <tr>
            <td>Соус:</td>
            <td>30</td>
            <td><?php echo $sauce ?></td>
            <td><?php echo $sauce*30 ?></td>
        </tr>
        <tr>
            <td>Сыр:</td>
            <td>40</td>
            <td><?php echo $cheese ?></td>
            <td><?php echo $cheese*40 ?></td>
        </tr>
        <tr>
            <td>Итог:</td>
            <td></td>
            <td></td>
            <td><?php echo $sum ?></td>
        </tr>

    </table>
</body>

</html>