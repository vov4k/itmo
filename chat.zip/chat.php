<?php
session_start();
if (isset($_SESSION['nick'])) {
	$nick = $_SESSION["nick"];
}else{
	header("Location: index.php");
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Чат</title>
</head>
<body>
<textarea readonly cols="100%" rows="25">
<?php
$handle = fopen("chat.txt", "r");
while(!feof($handle)){
    echo fgets($handle);
}
fclose($handle);

?>
</textarea>
    <form method="post" action="/write.php">
        <textarea placeholder="Сообшение" name="chat" cols="30" rows="10"></textarea>
        <input type="submit" value="Отправить">
    </form>
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
</body>
</html>
