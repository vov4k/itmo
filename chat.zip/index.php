<?php
session_start();
if (isset($_POST['nick'])) {
	$_SESSION["nick"] = $_POST["nick"];
	header("Location: chat.php");
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизация</title>
</head>
<body>
    <form method="post" action="/index.php">
        <input style="display: block"type="text" name="nick" placeholder="Ник"> <br>
        <input type="submit" value="Отправить">
    </form>
</body>
</html>
