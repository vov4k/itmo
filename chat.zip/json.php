<?php
define("FILE_NAME", "chat.txt");
$arr = [];
if(is_readable(FILE_NAME)){
    $handle = fopen(FILE_NAME, 'r');
    while(!feof($handle)){
        $arr[] = fgetc($handle);
    }
    fclose($handle);
}else{
    $arr[] = "Ошибка чтения файла";
}
echo json_encode($arr);
