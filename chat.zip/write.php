<?php
session_start();
if (isset($_SESSION['nick'])) {
	$nick = $_SESSION["nick"];
}else{
	header("Location: index.php");
}
if (isset($_POST["chat"])){
    $handle = fopen("chat.txt", "a+");
    fwrite($handle,trim($nick).": ". trim($_POST['chat'])." ".date ($date = date("H:i:s")). "\n");
    fclose($handle);
    }
header("Location: chat.php");
?>