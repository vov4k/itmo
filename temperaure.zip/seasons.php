<?php
$month = isset($_GET['month'])?$_GET['month']:0;
if($month<1 or $month>12){
    exit('Ошибка');
}
if($month<6){
    if($month<3){
        $month='Зима';
        $color='#00f';
    }else{
        $month='Весна';
        $color='#0f0';
    }
}else{
    if($month<9){
        $month='Лето';
        $color='#f00';
    }else if($month<12){
        $month='Осень';
        $color='#ff0';
    }else{
        $month='Зима';
        $color='#00f';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Времена года</title>
    <style>
        body{
            background-color: <?php echo $color;?>;
        }
    </style>
</head>
<body>
    <?php echo $month;?>
</body>
</html>
